//
//  NotificationService.h
//  OneSignalNotificationServiceExtension
//
//  Created by Jenna Antilla on 5/8/24.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
