cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/onesignal-cordova-plugin/dist/index.js",
        "id": "onesignal-cordova-plugin.OneSignalPlugin",
        "pluginId": "onesignal-cordova-plugin",
        "clobbers": [
            "OneSignal"
        ]
    },
    {
        "file": "plugins/onesignal-cordova-plugin/dist/NotificationReceivedEvent.js",
        "id": "onesignal-cordova-plugin.NotificationReceivedEvent",
        "pluginId": "onesignal-cordova-plugin"
    },
    {
        "file": "plugins/onesignal-cordova-plugin/dist/OSNotification.js",
        "id": "onesignal-cordova-plugin.OSNotification",
        "pluginId": "onesignal-cordova-plugin"
    },
    {
        "file": "plugins/onesignal-cordova-plugin/dist/UserNamespace.js",
        "id": "onesignal-cordova-plugin.UserNamespace",
        "pluginId": "onesignal-cordova-plugin"
    },
    {
        "file": "plugins/onesignal-cordova-plugin/dist/PushSubscriptionNamespace.js",
        "id": "onesignal-cordova-plugin.PushSubscriptionNamespace",
        "pluginId": "onesignal-cordova-plugin"
    },
    {
        "file": "plugins/onesignal-cordova-plugin/dist/DebugNamespace.js",
        "id": "onesignal-cordova-plugin.DebugNamespace",
        "pluginId": "onesignal-cordova-plugin"
    },
    {
        "file": "plugins/onesignal-cordova-plugin/dist/InAppMessagesNamespace.js",
        "id": "onesignal-cordova-plugin.InAppMessagesNamespace",
        "pluginId": "onesignal-cordova-plugin"
    },
    {
        "file": "plugins/onesignal-cordova-plugin/dist/SessionNamespace.js",
        "id": "onesignal-cordova-plugin.SessionNamespace",
        "pluginId": "onesignal-cordova-plugin"
    },
    {
        "file": "plugins/onesignal-cordova-plugin/dist/LocationNamespace.js",
        "id": "onesignal-cordova-plugin.LocationNamespace",
        "pluginId": "onesignal-cordova-plugin"
    },
    {
        "file": "plugins/onesignal-cordova-plugin/dist/NotificationsNamespace.js",
        "id": "onesignal-cordova-plugin.NotificationsNamespace",
        "pluginId": "onesignal-cordova-plugin"
    },
    {
        "file": "plugins/onesignal-cordova-plugin/dist/LiveActivitiesNamespace.js",
        "id": "onesignal-cordova-plugin.LiveActivitiesNamespace",
        "pluginId": "onesignal-cordova-plugin"
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "onesignal-cordova-plugin": "5.2.14"
}
// BOTTOM OF METADATA
});