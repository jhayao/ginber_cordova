// API configuration
export const API_BASE_URL = 'https://7az1q6wmve.execute-api.ap-southeast-1.amazonaws.com/api';
// export const API_BASE_URL = 'http://starter-kit.test/api';
export const PRODUCTS_API_URL = `${API_BASE_URL}/products`;
